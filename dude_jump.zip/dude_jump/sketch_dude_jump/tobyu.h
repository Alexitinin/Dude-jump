#include <avr/pgmspace.h>
#ifndef TOBYU_H
#define TOBYU_H

extern const unsigned char tobyu[];
#endif
