#include <avr/pgmspace.h>
#ifndef PLATE_H
#define PLATE_H

extern const unsigned char plate[];
#endif
