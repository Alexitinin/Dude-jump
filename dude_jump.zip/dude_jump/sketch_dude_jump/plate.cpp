#include "plate.h"

PROGMEM const unsigned char plate[] = {
8,2,
0xff, 0xff
};
