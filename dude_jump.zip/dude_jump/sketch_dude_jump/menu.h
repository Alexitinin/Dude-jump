#include <avr/pgmspace.h>
#ifndef MENU_H
#define MENU_H

extern const unsigned char menu[];
#endif
