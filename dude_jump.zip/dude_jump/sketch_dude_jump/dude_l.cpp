#include "dude_l.h"

PROGMEM const unsigned char dude_l[] = {
3,4,
0xc0, 0xe0, 0xe0, 0xa0
};
