#include "dude_r.h"

PROGMEM const unsigned char dude_r[] = {
3,4,
0x60, 0xe0, 0xe0, 0xa0
};
