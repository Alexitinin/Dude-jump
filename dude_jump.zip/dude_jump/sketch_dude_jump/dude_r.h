#include <avr/pgmspace.h>
#ifndef DUDE_R_H
#define DUDE_R_H

extern const unsigned char dude_r[];
#endif
