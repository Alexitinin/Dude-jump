#include <avr/pgmspace.h>
#ifndef GAME_OVER_H
#define GAME_OVER_H

extern const unsigned char game_over[];
#endif
