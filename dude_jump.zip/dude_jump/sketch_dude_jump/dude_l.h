#include <avr/pgmspace.h>
#ifndef DUDE_L_H
#define DUDE_L_H

extern const unsigned char dude_l[];
#endif
